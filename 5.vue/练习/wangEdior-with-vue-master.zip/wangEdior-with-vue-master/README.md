# wangEditor-with-vue

wangEditor 在 vue 中的使用

```
# 克隆项目
git clone git@github.com:wangeditor-team/wangEdior-with-vue.git

# 进入项目目录
cd wangEdior-with-vue

# 安装依赖
npm install

# 运行项目（将自动在浏览器打开 http://localhost:8080 ）
npm run serve
```

其中，wangEditor 相关的代码可参考 `src/views/Home.vue`
